import os
import logging
import json
import sqlite3
from datetime import datetime
from typing import Dict, Any

from telegram import (
    Update, 
    InlineKeyboardButton, 
    InlineKeyboardMarkup, 
    WebAppInfo
)
from telegram.ext import (
    Application, 
    CommandHandler, 
    CallbackQueryHandler, 
    ContextTypes,
    MessageHandler,
    filters
)

# Настройка логирования
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)
logger = logging.getLogger(__name__)

# Конфигурация
BOT_TOKEN = "8007589320:AAFXBxrh9bwR3-gVNe-JbuTeK1UMEJvz2pA"
WEB_APP_URL = "t.me/MaxGamers16TelegramBot/myapp"  # Замените на ваш URL

# Инициализация базы данных
def init_db():
    conn = sqlite3.connect('users.db')
    cursor = conn.cursor()
    
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS users (
            user_id INTEGER PRIMARY KEY,
            username TEXT,
            first_name TEXT,
            last_name TEXT,
            theme TEXT DEFAULT 'light',
            language TEXT DEFAULT 'ru',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS user_settings (
            user_id INTEGER PRIMARY KEY,
            notifications BOOLEAN DEFAULT 1,
            auto_save BOOLEAN DEFAULT 1,
            data TEXT,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users (user_id)
        )
    ''')
    
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS tasks (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            title TEXT,
            description TEXT,
            completed BOOLEAN DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users (user_id)
        )
    ''')
    
    conn.commit()
    conn.close()

def get_user_data(user_id: int) -> Dict[str, Any]:
    conn = sqlite3.connect('users.db')
    cursor = conn.cursor()
    
    cursor.execute('''
        SELECT u.*, us.notifications, us.auto_save, us.data 
        FROM users u 
        LEFT JOIN user_settings us ON u.user_id = us.user_id 
        WHERE u.user_id = ?
    ''', (user_id,))
    
    user = cursor.fetchone()
    conn.close()
    
    if user:
        return {
            'user_id': user[0],
            'username': user[1],
            'first_name': user[2],
            'last_name': user[3],
            'theme': user[4],
            'language': user[5],
            'notifications': bool(user[7]),
            'auto_save': bool(user[8]),
            'data': user[9] if user[9] else '{}'
        }
    return {}

def save_user_settings(user_id: int, settings: Dict[str, Any]):
    conn = sqlite3.connect('users.db')
    cursor = conn.cursor()
    
    # Обновляем или создаем пользователя
    cursor.execute('''
        INSERT OR REPLACE INTO users (user_id, username, first_name, last_name, theme, language)
        VALUES (?, ?, ?, ?, ?, ?)
    ''', (user_id, settings.get('username'), settings.get('first_name'), 
          settings.get('last_name'), settings.get('theme', 'light'), 
          settings.get('language', 'ru')))
    
    # Обновляем или создаем настройки
    cursor.execute('''
        INSERT OR REPLACE INTO user_settings (user_id, notifications, auto_save, data, updated_at)
        VALUES (?, ?, ?, ?, ?)
    ''', (user_id, settings.get('notifications', 1), settings.get('auto_save', 1),
          json.dumps(settings.get('data', {})), datetime.now()))
    
    conn.commit()
    conn.close()

def add_task(user_id: int, title: str, description: str = ""):
    conn = sqlite3.connect('users.db')
    cursor = conn.cursor()
    
    cursor.execute('''
        INSERT INTO tasks (user_id, title, description)
        VALUES (?, ?, ?)
    ''', (user_id, title, description))
    
    conn.commit()
    conn.close()

def get_user_tasks(user_id: int):
    conn = sqlite3.connect('users.db')
    cursor = conn.cursor()
    
    cursor.execute('''
        SELECT id, title, description, completed, created_at 
        FROM tasks 
        WHERE user_id = ? 
        ORDER BY created_at DESC
    ''', (user_id,))
    
    tasks = cursor.fetchall()
    conn.close()
    
    return [{
        'id': task[0],
        'title': task[1],
        'description': task[2],
        'completed': bool(task[3]),
        'created_at': task[4]
    } for task in tasks]

# Команда /start
async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    
    # Сохраняем пользователя
    user_data = {
        'username': user.username,
        'first_name': user.first_name,
        'last_name': user.last_name
    }
    save_user_settings(user.id, user_data)
    
    keyboard = [
        [InlineKeyboardButton("🚀 Открыть MiniApp", web_app=WebAppInfo(url=WEB_APP_URL))],
        [InlineKeyboardButton("📊 Моя статистика", callback_data="stats"),
         InlineKeyboardButton("✅ Мои задачи", callback_data="tasks")],
        [InlineKeyboardButton("⚙️ Настройки", callback_data="settings")]
    ]
    
    await update.message.reply_html(
        f"👋 Привет, {user.mention_html()}!\n\n"
        "Добро пожаловать в синхронизированного бота! 🎯\n\n"
        "<b>Что умеет этот бот:</b>\n"
        "• 📱 <b>MiniApp</b> - полная синхронизация с ботом\n"
        "• ✅ <b>Задачи</b> - управление задачами из бота и MiniApp\n"
        "• ⚙️ <b>Настройки</b> - синхронизированные настройки\n"
        "• 📊 <b>Статистика</b> - ваша активность\n\n"
        "Нажмите кнопку ниже, чтобы открыть MiniApp!",
        reply_markup=InlineKeyboardMarkup(keyboard)
    )

# Обработчик callback-запросов
async def button_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    
    user = query.from_user
    data = query.data
    
    if data == "stats":
        user_data = get_user_data(user.id)
        tasks = get_user_tasks(user.id)
        
        completed_tasks = len([t for t in tasks if t['completed']])
        total_tasks = len(tasks)
        
        stats_text = f"""
📊 <b>Ваша статистика</b>

👤 <b>Профиль:</b>
• Имя: {user.first_name}
• Username: @{user.username or 'не указан'}
• ID: <code>{user.id}</code>

✅ <b>Задачи:</b>
• Всего задач: {total_tasks}
• Выполнено: {completed_tasks}
• В процессе: {total_tasks - completed_tasks}

🎨 <b>Настройки:</b>
• Тема: {user_data.get('theme', 'light')}
• Уведомления: {'Включены' if user_data.get('notifications') else 'Выключены'}
"""
        keyboard = [
            [InlineKeyboardButton("📱 Открыть MiniApp", web_app=WebAppInfo(url=WEB_APP_URL))],
            [InlineKeyboardButton("🔙 Назад", callback_data="back")]
        ]
        await query.edit_message_text(stats_text, reply_markup=InlineKeyboardMarkup(keyboard), parse_mode='HTML')
    
    elif data == "tasks":
        tasks = get_user_tasks(user.id)
        
        if not tasks:
            tasks_text = "📝 У вас пока нет задач.\n\nСоздайте первую задачу в MiniApp!"
        else:
            tasks_text = "📝 <b>Ваши задачи:</b>\n\n"
            for task in tasks[:5]:  # Показываем последние 5 задач
                status = "✅" if task['completed'] else "⏳"
                tasks_text += f"{status} <b>{task['title']}</b>\n"
                if task['description']:
                    tasks_text += f"   📄 {task['description']}\n"
                tasks_text += f"   📅 {task['created_at'][:10]}\n\n"
        
        keyboard = [
            [InlineKeyboardButton("📱 Управлять задачами", web_app=WebAppInfo(url=WEB_APP_URL))],
            [InlineKeyboardButton("🔙 Назад", callback_data="back")]
        ]
        await query.edit_message_text(tasks_text, reply_markup=InlineKeyboardMarkup(keyboard), parse_mode='HTML')
    
    elif data == "settings":
        user_data = get_user_data(user.id)
        
        settings_text = f"""
⚙️ <b>Ваши настройки</b>

🎨 <b>Внешний вид:</b>
• Тема: {user_data.get('theme', 'light')}
• Язык: {user_data.get('language', 'ru')}

🔔 <b>Уведомления:</b>
• Уведомления: {'Включены' if user_data.get('notifications') else 'Выключены'}
• Автосохранение: {'Включено' if user_data.get('auto_save') else 'Выключено'}

💡 <b>Для изменения настроек используйте MiniApp</b>
"""
        keyboard = [
            [InlineKeyboardButton("🎨 Настроить в MiniApp", web_app=WebAppInfo(url=WEB_APP_URL))],
            [InlineKeyboardButton("🔙 Назад", callback_data="back")]
        ]
        await query.edit_message_text(settings_text, reply_markup=InlineKeyboardMarkup(keyboard), parse_mode='HTML')
    
    elif data == "back":
        await start(update, context)

# Обработка данных из MiniApp
async def handle_web_app_data(update: Update, context: ContextTypes.DEFAULT_TYPE):
    try:
        web_app_data = update.message.web_app_data
        data_str = web_app_data.data
        user = update.effective_user
        
        data = json.loads(data_str)
        action = data.get('action')
        
        if action == 'save_settings':
            settings = data.get('settings', {})
            save_user_settings(user.id, settings)
            
            await update.message.reply_text(
                "✅ Настройки сохранены и синхронизированы!\n\n"
                f"Тема: {settings.get('theme', 'light')}\n"
                f"Язык: {settings.get('language', 'ru')}\n"
                f"Уведомления: {'Включены' if settings.get('notifications') else 'Выключены'}"
            )
        
        elif action == 'create_task':
            title = data.get('title')
            description = data.get('description', '')
            
            if title:
                add_task(user.id, title, description)
                
                tasks = get_user_tasks(user.id)
                total_tasks = len(tasks)
                completed_tasks = len([t for t in tasks if t['completed']])
                
                await update.message.reply_text(
                    f"✅ Задача создана!\n\n"
                    f"<b>{title}</b>\n"
                    f"{description}\n\n"
                    f"📊 Статистика: {completed_tasks}/{total_tasks} выполнено",
                    parse_mode='HTML'
                )
        
        elif action == 'sync_data':
            user_data = get_user_data(user.id)
            tasks = get_user_tasks(user.id)
            
            sync_data = {
                'user': user_data,
                'tasks': tasks,
                'sync_time': datetime.now().isoformat()
            }
            
            # Можно отправить данные обратно в MiniApp через сообщение
            await update.message.reply_text(
                f"🔄 Данные синхронизированы!\n\n"
                f"• Задач: {len(tasks)}\n"
                f"• Настройки: {user_data.get('theme', 'light')} тема\n"
                f"• Время: {datetime.now().strftime('%H:%M:%S')}"
            )
        
        logger.info(f"Данные от {user.id}: {action}")
        
    except Exception as e:
        await update.message.reply_text("❌ Ошибка при обработке данных")
        logger.error(f"Ошибка: {e}")

# Команда для синхронизации
async def sync_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    user_data = get_user_data(user.id)
    tasks = get_user_tasks(user.id)
    
    completed = len([t for t in tasks if t['completed']])
    total = len(tasks)
    
    await update.message.reply_html(
        f"🔄 <b>Синхронизация данных</b>\n\n"
        f"✅ <b>Задачи:</b> {completed}/{total} выполнено\n"
        f"🎨 <b>Тема:</b> {user_data.get('theme', 'light')}\n"
        f"🔔 <b>Уведомления:</b> {'Включены' if user_data.get('notifications') else 'Выключены'}\n\n"
        f"<i>Используйте MiniApp для управления данными</i>",
        reply_markup=InlineKeyboardMarkup([[
            InlineKeyboardButton("📱 Открыть MiniApp", web_app=WebAppInfo(url=WEB_APP_URL))
        ]])
    )

def main():
    # Инициализация БД
    init_db()
    
    # Создаем приложение
    application = Application.builder().token(BOT_TOKEN).build()
    
    # Добавляем обработчики
    application.add_handler(CommandHandler("start", start))
    application.add_handler(CommandHandler("sync", sync_command))
    application.add_handler(CallbackQueryHandler(button_handler))
    application.add_handler(MessageHandler(filters.StatusUpdate.WEB_APP_DATA, handle_web_app_data))
    
    # Запускаем бота
    print("🤖 Бот запущен и готов к синхронизации...")
    application.run_polling()

if __name__ == "__main__":
    main()